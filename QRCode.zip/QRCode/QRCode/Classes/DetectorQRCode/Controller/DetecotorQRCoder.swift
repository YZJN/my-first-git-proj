//
//  DetecotorQRCoder.swift
//  QRCode
//
//  Created by llx on 2017/11/21.
//  Copyright © 2017年 llx. All rights reserved.
//

import UIKit

class DetecotorQRCoder: UIViewController {

    @IBOutlet weak var souceImageView: UIImageView!
    
    @IBAction func detectorQRCode(_ sender: Any) {
//        // 1、获取需要识别的图片
//        let image = souceImageView.image
//        let ciImage = CIImage(image: image!)
//        // 2、开始识别
//        //2.1创建一个二维码探测器
//        let dector = CIDetector(ofType: CIDetectorTypeQRCode, context: nil, options: [CIDetectorAccuracy:CIDetectorAccuracyHigh])
//        //2.2直接探测二维码特征
//      let features = dector?.features(in: ciImage!)
//        for feature in features! {
//            let qrFeature = feature as!CIQRCodeFeature
//            print(qrFeature.messageString as Any)
//        }
        let image = souceImageView.image
        let ciImage = CIImage(image: image!)
        let detector = CIDetector(ofType: CIDetectorTypeQRCode, context: nil, options: [CIDetectorAccuracy:CIDetectorAccuracyHigh])
        let features = detector?.features(in: ciImage!)
        for feature in features! {
            let qrFeatures = feature as!CIQRCodeFeature
            print(qrFeatures.messageString)
        }
        
    }
    
}
