//
//  GeneratorQRCoder.swift
//  QRCode
//
//  Created by llx on 2017/11/21.
//  Copyright © 2017年 llx. All rights reserved.
//

import UIKit
import CoreImage
class GeneratorQRCoder: UIViewController {
    @IBOutlet weak var qrCoderImageView: UIImageView!
    
    @IBOutlet weak var inputTextView: UITextView!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        //1、创建二维码滤镜 name后的编码不能输错
        let filter = CIFilter(name: "CIQRCodeGenerator")
        //2、设置滤镜的输入数据
        //用KVC设置
        let  str = inputTextView.text
        let data = str?.data(using:String.Encoding.utf8)
        filter?.setValue(data, forKey: "inputMessage")
        filter?.setValue("M", forKey: "inputCorrectionLevel")
//        filter?.setValue("M", forKey: "inputCorrectionLevel")
        //3、从二维码中获取结果
        if var  image = filter?.outputImage {
            let transform = CGAffineTransform(scaleX: 20, y: 20)
            image = image.transformed(by: transform)
            var resultImage = UIImage(ciImage: image)
            print(resultImage.size)
            let center = UIImage(named: "img_1.jpg")
            resultImage = getNewImage(souceImage: resultImage, center: center!)
//            let center = UIImage(named: "img_1.jpg")
//            resultImage = getNewImage(sourceImage: resultImage, center: center!)
            //显示结果
            qrCoderImageView.image = resultImage
        }
    }
    func getNewImage(souceImage:UIImage,center:UIImage) -> UIImage {
        let size = souceImage.size
        UIGraphicsBeginImageContext(size)
        souceImage.draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        let width:CGFloat = 80
        let height:CGFloat = 80
        let x = (size.width - width)*0.5
        let y = (size.height - height)*0.5
        center.draw(in: CGRect(x: x, y: y, width: width, height: height))
        let resultImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return resultImage!
    }
//    func getNewImage(sourceImage:UIImage,center:UIImage) -> UIImage {
//
//        let size = sourceImage.size
//        //开启图形上下文
//        UIGraphicsBeginImageContext(size)
//        //绘制大图片
//        sourceImage.draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
//        //绘制小图片
//        let width:CGFloat = 80
//        let height:CGFloat = 80
//        let x :CGFloat = (size.width-width)*0.5
//        let y:CGFloat = (size.height-height)*0.5
//
//        center.draw(in: CGRect(x: x, y: y, width: width, height: height))
//        //取出结果图片
//        let resultImage = UIGraphicsGetImageFromCurrentImageContext()
//        //关闭上下文
//        UIGraphicsEndImageContext()
//        //返回图片
//        return resultImage!
//    }
}
