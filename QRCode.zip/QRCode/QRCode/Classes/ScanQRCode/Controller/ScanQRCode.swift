//
//  ScanQRCode.swift
//  QRCode
//
//  Created by llx on 2017/11/21.
//  Copyright © 2017年 llx. All rights reserved.
//

import UIKit
import AVFoundation
class ScanQRCode: UIViewController {

    @IBOutlet weak var scanBgView: UIView!
    @IBOutlet weak var toButtom: NSLayoutConstraint!
    var session:AVCaptureSession?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        startScan() 
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startScanAnimation()
    }
    func startScan() -> () {
        //1设置输入
           //1.1获取摄像头
        let device = AVCaptureDevice.default(for: AVMediaType.video)
            //1.2把摄像头设备当做输入设备
        var input:AVCaptureDeviceInput?
        do {
            input = try AVCaptureDeviceInput(device: device!)
        } catch {
            print(error)
            return
        }
        //2设置输出
        let output = AVCaptureMetadataOutput()
        //2.1设置结果处理的代理
        output.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        //3创建会话，连接输入和输出
         session = AVCaptureSession()
        //并非所有的设备都能被添加进来，所以要做判断
        if session!.canAddInput(input!)&&session!.canAddOutput(output){
            session!.addInput(input!)
            session!.addOutput(output)
        }else{
            return
        }
        //设置二维码可以识别的码制
        output.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        //添加视频预览图层 （让用户可以看到界面）
        let layer = AVCaptureVideoPreviewLayer(session:session!)
        layer.frame = view.layer.bounds
//        view.layer.addSublayer(layer)
        view.layer.insertSublayer(layer, at: 0)
        
        //4启动会话，让输入开始采集数据，输出对象，开始处理数据
        session!.startRunning()
    }

}
extension ScanQRCode:AVCaptureMetadataOutputObjectsDelegate{
    //扫描到结果之后调用
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
//        print("test========")
        print(metadataObjects)
    }
}
extension ScanQRCode {
    func startScanAnimation() -> () {
        toButtom.constant = scanBgView.frame.size.height
        //重新布局
        view.layoutIfNeeded()
        //修改
        toButtom.constant = -scanBgView.frame.size.height
        //添加动画
        UIView.animate(withDuration: 1) {
            UIView.setAnimationRepeatCount(MAXFLOAT)
            self.view.layoutIfNeeded()
        }
        
    }
}
